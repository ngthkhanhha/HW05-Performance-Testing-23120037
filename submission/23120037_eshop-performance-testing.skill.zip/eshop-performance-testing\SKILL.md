---
name: eshop-performance-testing
description: Design, run, analyze, and document JMeter performance scenarios for the EShop Node.js and SQLite API. Use for Load, Stress, Spike, Endurance, JTL review, or a continuous-testing proposal.
---

# Kiểm thử hiệu năng EShop

Hướng dẫn một quy trình có thể lặp lại để kiểm thử EShop, giữ dấu vết AI và chỉ kết luận từ bằng chứng đã thu thập.

## Quy trình

1. Đọc `README.md`, `api_specification.md`, mã route/backend và yêu cầu bài tập. Xác định base URL, trạng thái dữ liệu, tài khoản thử và nhóm endpoint cần bao phủ.
2. Thiết kế các kịch bản Load, Stress và Spike trên cùng một luồng nghiệp vụ đầu-cuối. Ghi rõ số luồng, ramp-up, thời lượng, think-time, nguồn CSV, listener và lý do chọn các tham số. Với luồng mua hàng, bao phủ xác thực, đọc sản phẩm và giao dịch giỏ hàng/checkout.
3. Trước khi chạy, kiểm tra từng trường thực tế trong JMX: biến CSV, JSON extractor, header Authorization, dữ liệu gửi, assertion, hành vi khi sampler lỗi và đường dẫn JTL. Không suy ra cấu hình từ tên tệp hoặc ảnh giao diện.
4. Dùng database/tài khoản kiểm thử cô lập. Xác nhận backend đúng cổng và trạng thái sạch; không dùng lệnh dừng tiến trình diện rộng. Nếu backend khởi động lại có thể xóa bảng hoặc seed lại dữ liệu, giữ bản sao lưu và xác nhận đường dẫn DB trước khi chạy.
5. Lưu JTL thô đầy đủ và tạo HTML dashboard riêng cho mỗi lần chạy. Lưu ảnh JMeter cùng tài nguyên của đúng tiến trình backend; ghi nhận phần cứng, hostname, phiên bản công cụ và thông số tải. Gắn nhãn ảnh là đang chạy, hoàn tất, hoặc chỉ chụp lúc bắt đầu.
6. Với Endurance, chạy 10–15 phút ở tải duy trì; nếu cần tìm giới hạn, tăng tải theo từng bậc, theo dõi lỗi, p95, thông lượng và bộ nhớ liên tục. Một lần chạy thành công ở một tải chỉ chứng minh điểm tải đó ổn định trong khoảng thời gian đo, không chứng minh đó là cực đại.
7. Phân tích mỗi JTL bằng `scripts/analyze_jtl.py`. Đối chiếu tổng mẫu, mã HTTP, success, p95, độ trễ tối đa và cửa sổ thời gian. Chỉ so sánh các lượt có cùng runner, dữ liệu, JMeter và tải. Báo rõ số đo, suy luận, khuyến nghị và giới hạn.
8. Ghi nhật ký AI cho từng phiên: công cụ/model nếu biết, ngày giờ, lời nhắc và đầu ra. Tách riêng kết quả AI khỏi phần người học tự rà soát; không viết thay xác nhận, tự chấm điểm hay trải nghiệm của người học.
9. Lưu kết luận và đề xuất CI trong Markdown. Đưa Task 3 vào kết luận, kèm flow chart, trigger theo commit, so sánh p95, quy tắc chạy xác nhận, chi phí và nguy cơ báo động giả.

## Cách đọc số liệu

- `p95` trong script dùng nearest-rank: phần tử ở vị trí `ceil(0.95 × n)` sau khi sắp xếp độ trễ tăng dần.
- Thời lượng và thông lượng suy ra từ thời điểm bắt đầu mẫu sớm nhất đến thời điểm kết thúc mẫu muộn nhất trong JTL.
- Không coi HTTP 200 hoặc `success=true` là assertion nghiệp vụ. Kiểm tra nội dung phản hồi và trạng thái được tạo trước khi kết luận giao dịch đúng.
- Không công bố mật khẩu, JWT hoặc dữ liệu cá nhân trong log công khai. Dùng dữ liệu kiểm thử giả và lưu file thô theo yêu cầu nộp bài.
- Khi tài nguyên máy chạy tải và API cùng lúc, ghi rõ mức sử dụng là toàn hệ thống hay của riêng tiến trình backend.

## Công cụ phân tích JTL

Chạy từ thư mục repository. Sau khi giải nén skill, đặt `$SkillDir` trỏ tới thư mục `eshop-performance-testing` và `$JtlPath` trỏ tới log cần phân tích:

```powershell
$SkillDir = ".\submission\skills\eshop-performance-testing"
$JtlPath = ".\submission\results\load\load_run_01.jtl"
python "$SkillDir\scripts\analyze_jtl.py" $JtlPath
```

Script dùng thư viện chuẩn Python và in JSON cho từng nhãn sampler cùng tổng thể.
