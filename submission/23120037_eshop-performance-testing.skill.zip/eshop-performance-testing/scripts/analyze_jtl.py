#!/usr/bin/env python3
"""Summarize a JMeter CSV JTL using only the Python standard library."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean


def percentile_nearest_rank(values: list[int], percentile: float) -> int | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(percentile * len(ordered)) - 1)]


def summarize(rows: list[dict[str, str]]) -> dict[str, object]:
    elapsed = [int(row["elapsed"]) for row in rows]
    starts = [int(row["timeStamp"]) for row in rows]
    ends = [int(row["timeStamp"]) + int(row["elapsed"]) for row in rows]
    window_seconds = max(0.0, (max(ends) - min(starts)) / 1000.0)
    errors = [row for row in rows if row.get("success", "").lower() != "true"]
    codes = Counter(row.get("responseCode", "") for row in rows)
    return {
        "samples": len(rows),
        "errors": len(errors),
        "error_percent": round(100 * len(errors) / len(rows), 4) if rows else None,
        "http_codes": dict(sorted(codes.items())),
        "mean_ms": round(mean(elapsed), 3) if elapsed else None,
        "p90_ms": percentile_nearest_rank(elapsed, 0.90),
        "p95_ms": percentile_nearest_rank(elapsed, 0.95),
        "p99_ms": percentile_nearest_rank(elapsed, 0.99),
        "max_ms": max(elapsed) if elapsed else None,
        "window_seconds": round(window_seconds, 3),
        "throughput_per_second": round(len(rows) / window_seconds, 4) if window_seconds else None,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jtl", type=Path, help="JMeter CSV JTL file")
    args = parser.parse_args()
    try:
        with args.jtl.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            required = {"timeStamp", "elapsed", "label", "responseCode", "success"}
            missing = required - set(reader.fieldnames or [])
            if missing:
                raise ValueError(f"Missing required JTL columns: {', '.join(sorted(missing))}")
            rows = list(reader)
        by_label: dict[str, list[dict[str, str]]] = defaultdict(list)
        for row in rows:
            by_label[row.get("label", "")].append(row)
        result = {
            "file": str(args.jtl),
            "overall": summarize(rows),
            "samplers": {label: summarize(group) for label, group in sorted(by_label.items())},
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, KeyError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
